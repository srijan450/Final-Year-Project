Dr. Rahul Raoniar modified the template to fulfill the Indian Institute of Technology Bombay B.Tech/M.Tech/Ph.D. student's  dissertation/thesis requirements.

Sugeet Sunder prepared the earlier version of this template. The thesis style was initially created by Steve R. Gunn and modified into a template for IIT Kanpur by Sunil Patel and further to an IIT Delhi template by Sugeet Sunder.

Feel free to use it, modify it, and share it.


# Notes:

1. Dummy texts are added using libsum package
2. You can use the chapter template to add more intermediate chapters